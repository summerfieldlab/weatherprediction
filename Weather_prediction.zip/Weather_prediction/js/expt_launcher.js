
<!-- Block methods -->
function newBlock() {
  hideTrial();
  hideFeedback();
  showBlock();
  drawProgress()
  saveExperiment();
}

function startBlock() {
  if (coding.newblock){
    coding.newblock  = false;
    hideBlock();
    if(coding.block==(parameters.nb_blocks + parameters.testNb_blocks)){ // can still use this for interleaved train + test
      finishExperiment_data();
    }
    newTrial();
  }
}

// <!-- Trial methods -->
function nextTrial() {
   // INCREMENT TRIAL
   hideStimuli();
  coding.index++;
  coding.trial++;


  if(coding.warmup){
    // warm up block increment
    if(coding.trial == parameters.warmup_nb_trials){
      var percentCorrect = 100*getCorrectWarmup()/parameters.warmup_nb_trials;
      disp(percentCorrect + '% correct!');
      if(percentCorrect >= 75){
        finishWarmup();
        return;
      }
      else{
        coding.warmup_block++;
        coding.trial = 0;
        genWarmupBlock();
        coding.newblock = true;
        newBlock();
        return;
      }
    }
  }

  // INCREMENT TRAIN BLOCK
  if (coding.train){
    if (coding.trial==parameters.nb_trials) {
      calculateBonus();

      coding.block++;
      coding.trial=0;

      // END OF TRAINING
      getTrainORTest(); // checks block number and switches from coding.train to coding.test if necessary
      // if (coding.block==parameters.nb_blocks) {
      //   coding.train = false;
      //   coding.test  = true;
      // }

      // NEW BLOCK
      coding.newblock  = true;
      newBlock();

      return;
    }
  }
  else if (coding.test){
   //increment test block
       // END OF EXPERIMENT
   if (coding.trial==parameters.testNb_trials) {
      calculateBonus();
      coding.block++;
      if (coding.block==(parameters.nb_blocks + parameters.testNb_blocks)){
        coding.newblock = true;
        newBlock();
        return;
      }
      getTrainORTest();
      coding.trial=0;
      coding.newblock = true;
      newBlock();

      return;
     } 
  }
  // NEW TRIAL
  newTrial();
}

function newTrial() {
  if (!startedexperiment || !coding.instructions.finished || finishedexperiment) { return; }
  // update
  updateSdata();
  hideFeedback();

  if(coding.train && parameters.cond == 1){
    loadImages(parameters.stimTrainParal[coding.trainIndex],parameters.stimLocsTrain[coding.trainIndex]);
  }
  else if (coding.test){
    loadImages(parameters.stimTest[coding.testIndex], parameters.stimLocsTest[coding.testIndex]);
  }
  else if (coding.train && parameters.cond == 0){
    loadImages(parameters.stimTrainCurr[coding.trainIndex], parameters.stimLocsTrain[coding.trainIndex]);
    // loadImageCurr(parameters.stimTrainCurr[coding.trainIndex], parameters.stimLocsTrain[coding.trainIndex]);
  }
  else if (coding.warmup){
    loadImageCurr(parameters.stimWarmup[coding.warmup_block][coding.trial]);
  } 

  hideStimuli();
  // show
  setTimeout(showTrial, parameters.stimulus_timein)
  // showTrial();

  showInstructions();
  // timestamp
  coding.timestamp = getTimestamp();

  // allow answering
  if (coding.warmup || (parameters.cond%2==0 && (coding.testIndex==-1 && coding.trainIndex%100<50)))
  {setTimeout(allowAnswering, parameters.isi+parameters.response_lockout_buffer)}
  else
  {setTimeout(allowAnswering, parameters.response_lockout+parameters.response_lockout_buffer)}
  coding.newblock  = false;
  //2sec window before response 

}

function allowAnswering(){
  coding.answering=true; 
  colourFixation(board.fixation, "#555");
  // board.countdown.object.attr({"opacity": 0})
  startCountdown()
}

function delay_countdown(){
  board.countdown.object.attr({"opacity": 1})
}

// INSTRUCTIONS

// START
function launchInstructions() {
  coding.instructions.started = true
  coding.instructions.instructions = getInstructions()
  // jwerty.key('→',handleInstructionsForward);
  jwerty.key('↑',handleInstructionsBackward);
  jwerty.key('↓',handleInstructionsForward);
  // jwerty.key('←',handleInstructionsBackward);
  updateInstructions();
}

function finishInstructions() {
  coding.instructions.finished = true;
  removeInstStim();
  board.paper.bg.remove();
  clearTimeout(coding.timeout)
  launchExperiment();
}
// MOVE BACKWARD / FORWARD
function handleInstructionsForward()  { handleInstructionsClick(false) }
function handleInstructionsBackward() { handleInstructionsClick(true)  }
function handleInstructionsClick(backward) {
  if (!coding.instructions.started) { return }
  if (coding.instructions.finished) { return }
  if (coding.instructions.wait)     { return }
  if (backward) { coding.instructions.index-- } else { coding.instructions.index++ }
  updateInstructions();
  coding.instructions.wait = true;
}
function interInstructions() {
  if(coding.instructions.finished) { return }
  coding.instructions.wait = false
  board.instructions.next.object.attr({"opacity":1});
}

// UPDATE TRAINING SCREEN
function updateInstructions() {
  if (coding.instructions.finished) { return }
  if (coding.instructions.index<0)  { coding.instructions.index = 0 }
  // apply instructions
  var i = coding.instructions.index
  var f = coding.instructions.instructions[i].func
  var a = coding.instructions.instructions[i].args
  f(a)
  coding.instructions.wait = true
  board.instructions.next.object.attr({"opacity":0});
  parameters.instructions_wait = 0;
  coding.timeout = setTimeout(interInstructions,parameters.instructions_wait);
}



