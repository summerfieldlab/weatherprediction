
<!-- Update methods -->


function updateSdata() {
  if(coding.warmup){
    sdata.expt_index[coding.index] = coding.index;
    sdata.expt_trial[coding.index] = coding.trial;
    sdata.expt_block[coding.index] = coding.block;

    sdata.vbxi_category[coding.index] = parameters.outcWarmup[coding.warmup_block][coding.trial];             
    // disp(parameters.probWarmup[coding.warmup_block][coding.trial]);

    sdata.corrRespProb[coding.index]  = parameters.corrProbRespWarmup[coding.index];
  }


  else{
    updateIndices();
    
    sdata.expt_index[coding.index]  = coding.index;
    sdata.expt_trial[coding.index]  = coding.trial;
    sdata.expt_block[coding.index]  = coding.block;

    if(coding.train){
  	 if(parameters.cond == 0){ //curriculum learning
  		  sdata.vbxi_category[coding.index] = parameters.outcTrainCurr[coding.trainIndex]; // coding.index runs through entire experiment while trainIndex/testIndex start with the first train/test trial
  		  sdata.corrRespProb[coding.index]  = parameters.corrProbRespTrain[coding.trainIndex];
        // disp(parameters.probTrainCurr[coding.trainIndex]);
  	 }
  	 else{
  		  sdata.vbxi_category[coding.index] = parameters.outcTrainParal[coding.trainIndex];
  		  // disp(parameters.logLRtrainParal[coding.trainIndex]);

  	 }
    sdata.corrRespProb[coding.index]  = parameters.corrProbRespTrain[coding.trainIndex];
    // disp('locs ' + parameters.stimLocsTrain[coding.trainIndex])
    }
    else if(coding.test){
  	 sdata.vbxi_category[coding.index] = parameters.outcTest[coding.testIndex];
     // disp(parameters.logLRtest[coding.testIndex]);
     sdata.corrRespProb[coding.index]  = parameters.corrProbRespTest[coding.testIndex];
     // disp('locs: ');
     // disp(parameters.stimLocsTest[coding.testIndex]);
     // disp('stims');
     // disp(parameters.stimTest[coding.testIndex]);
    }
  }
}