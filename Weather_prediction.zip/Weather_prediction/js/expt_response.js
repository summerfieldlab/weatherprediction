
<!-- Response methods -->
function handleLeft()  { handleResponse('Left', 0); }
function handleRight() { handleResponse('Right',1); }

function handleResponse(key,category) {
  if(coding.answering){
    if(parameters.noRespCount > 100){
      handleNoResponse();
    }
    else {
      coding.answering = false;
      clearTimeout(board.stimuli.timeout); // reset the countdown for the stimuli to disappear after 2 secs
      stopCountdown();
      saveResponse(key,category);
      removeStimuli();
      showFeedback();
      if(sdata.resp_correct[coding.index]){
        setTimeout(nextTrial,parameters.feedpos_timeout);
      } 
      else {
        setTimeout(nextTrial,parameters.feedneg_timeout);
      }
    }
  }
  else{
      sdata.betwTrialPressPerTrial[coding.trainIndex+coding.testIndex+1]++; 
      var betwtrialpress = getSecs(coding.timestamp)*1000;
      var cur_bin = Math.floor(betwtrialpress/100); 
      if ((cur_bin<20)&&(cur_bin>=0)){ sdata.betwTrialKeyPress[coding.trainIndex+coding.testIndex+1][cur_bin]++; }
    }
}

function handleNoResponse() {
  if(!isFullscreen() && startedexperiment && !finishedexperiment) {
    finishExperiment_noresponse();
  }
}

function saveResponse(key,category) {
  sdata.resp_timestamp[coding.index]         = getTimestamp();
  sdata.resp_reactiontime[coding.index]      = getSecs(coding.timestamp);
  sdata.resp_category[coding.index]          = category;
  sdata.resp_correct[coding.index]           = bin2num(sdata.vbxi_category[coding.index]==sdata.resp_category[coding.index]);
  
  if(sdata.corrRespProb[coding.index] == -1){
    sdata.resp_correct_prob[coding.index]    = -1;
  }
  else{
    sdata.resp_correct_prob[coding.index]    = bin2num(sdata.corrRespProb[coding.index] == sdata.resp_category[coding.index]);
  }
}
