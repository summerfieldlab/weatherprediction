
var sdata;
var edata;
var parameters;
var board;
var coding;

function 
setExperiment() {
  // EDATA ----------------
  edata = {};
  // expt
  edata.expt_subject = participant_id;
  edata.expt_sex     = participant_gender;
  edata.expt_age     = participant_age;
  edata.expt_task    = participant_task;

  edata.expt_turker  = participant_turker;

  // PARAMETERS -----------
  parameters = {};

  //time outs
  parameters.stimulus_timein  =   500;  // until when fixation is on-screen
  parameters.response_lockout =  4800;  // time between stimulus presentation and onset of response window
  parameters.response_lockout_buffer = 500
  parameters.stim_onscreen    = 1000
  parameters.isi              = parameters.response_lockout/4 // inter-stimulus interval
  parameters.response_timeout = 15000;  // response warning delay
  parameters.warnings_timeout = 5000;  // response warning time

  parameters.feedpos_timeout  =  1300;  // feedback time (good)
  parameters.feedneg_timeout  =  1600;  // feedback time (bad)

  // conditions
  // curriculum vs parallel learning
  parameters.cond              = 1; // parseInt(getQueryParams().c); //0: curriculum, 1: parallel learning
  // disp('CURR TRAIN CONDITION MANUALLY SELECTED.');
  if(parameters.cond == 0){
    parameters.training_method = 0; // parseInt(getQueryParams().t); //0: block, 1: interleaved
  }
  //stimulus condition
  parameters.imageCond         = Math.round(Math.random()); // parseInt(getQueryParams().i); //0: shapes, 1: animals

  // key assignment
  parameters.keys              = Math.round(Math.random());  //parseInt(getQueryParams().k); //k=0: left = bad weather(0), right = good weather(1); k=1: vice versa

  parameters.interl_test       = 0 // parseInt(getQueryParams().i); //0: false - first 8 blocks of train, then 8 blocks of test, 1: 1 block train, 1 test, 1 train, ...

  if(parameters.interl_test == undefined){
    parameters.interl_test = Math.round(Math.random());
    disp('random inter_test bc i not defined in URL');
  }

  // stimuli
  parameters.numStimuli = 8;
  if(parameters.imageCond == 0){
    parameters.stimDict = {
      0:"http://185.47.61.11/sandbox/tasks/lucy/WeatherPrediction_template/Images/shape1.png",
      1:"http://185.47.61.11/sandbox/tasks/lucy/WeatherPrediction_template/Images/shape2.png",
      2:"http://185.47.61.11/sandbox/tasks/lucy/WeatherPrediction_template/Images/shape3.png",
      3:"http://185.47.61.11/sandbox/tasks/lucy/WeatherPrediction_template/Images/shape4.png",
      4:"http://185.47.61.11/sandbox/tasks/lucy/WeatherPrediction_template/Images/shape5.png",
      5:"http://185.47.61.11/sandbox/tasks/lucy/WeatherPrediction_template/Images/shape6.png",
      6:"http://185.47.61.11/sandbox/tasks/lucy/WeatherPrediction_template/Images/shape7.png",
      7:"http://185.47.61.11/sandbox/tasks/lucy/WeatherPrediction_template/Images/shape8.png"  
    };
  }
  else{
    parameters.stimDict = {
      0:"http://185.47.61.11/sandbox/tasks/lucy/WeatherPrediction_template/Images/animal1.png",
      1:"http://185.47.61.11/sandbox/tasks/lucy/WeatherPrediction_template/Images/animal2.png",
      2:"http://185.47.61.11/sandbox/tasks/lucy/WeatherPrediction_template/Images/animal3.png",
      3:"http://185.47.61.11/sandbox/tasks/lucy/WeatherPrediction_template/Images/animal4.png",
      4:"http://185.47.61.11/sandbox/tasks/lucy/WeatherPrediction_template/Images/animal5.png",
      5:"http://185.47.61.11/sandbox/tasks/lucy/WeatherPrediction_template/Images/animal6.png",
      6:"http://185.47.61.11/sandbox/tasks/lucy/WeatherPrediction_template/Images/animal7.png",
      7:"http://185.47.61.11/sandbox/tasks/lucy/WeatherPrediction_template/Images/animal8.png"  
    };
  }

  parameters.probabilities = [0.9, 0.8, 0.7, 0.6, 0.4, 0.3, 0.2, 0.1];
  parameters.probDict = {};
  for(var i=0;i<parameters.numStimuli;i++){
    var rand = Math.floor(Math.random()*8);
    if(parameters.probDict[rand] == undefined){
      parameters.probDict[rand] = parameters.probabilities[i];
    }
    else{
      i--;
    }
  }
  //disp(parameters.probDict);

  //warm up:
  parameters.warmupStimDict = {
    0:"http://185.47.61.11/sandbox/tasks/lucy/WeatherPrediction_template/Images/trumpet.png",
    1:"http://185.47.61.11/sandbox/tasks/lucy/WeatherPrediction_template/Images/guitar.png"
  };

  parameters.warmupProbs    = [0.1, 0.9];
  parameters.warmupProbDict = {};
  if(Math.floor(Math.random()*2) == 0){
    parameters.warmupProbDict[0] = parameters.warmupProbs[0];
    parameters.warmupProbDict[1] = parameters.warmupProbs[1];
  }
  else{
    parameters.warmupProbDict[0] = parameters.warmupProbs[1];
    parameters.warmupProbDict[1] = parameters.warmupProbs[0];
  }


  parameters.stimTrainCurr        = {};
  parameters.probTrainCurr        = {};
  parameters.outcTrainCurr        = {};
  parameters.stimTrainParal       = {};
  parameters.probTrainParal       = {};
  parameters.logLRtrainParal      = {};
  parameters.logLRtrainCurr       = {};
  parameters.outcTrainParal       = {};
  parameters.corrProbRespTrain    = {}; // correct solution (judged by prob for each trial: 1 = right is correct, 0 = left is correct, -1: 50-50)
  parameters.stimTest             = {};
  parameters.probTest             = {};
  parameters.logLRtest            = {};
  parameters.outcTest             = {};
  parameters.corrProbRespTest     = {}; // correct solution (judged by prob for each trial: 1 = right is correct, 0 = left is correct, -1: 50-50)

 // parameters.resCombs             = []; // for parallel training only: save 12 stimulus combination that will only be shown during testing, not during training.
 // parameters.trainCombs           = {}; // same as above but in list of strings format - easier to work with.
 // parameters.newTestCombInd       = []; // test trial indices at which the reserved trials from parallel training were first encountered.
 // parameters.testCombs            = {}; // all combinations other than the p = 0.5 ones (--> excluded.)
 // parameters.testOnlyCombs        = [];
 // parameters.novelStimComb        = {}; // false: parallel train Ps were trained on the combination present at trial i; true: they weren't.

  parameters.allCombs             = []; 
  parameters.allValidCombs        = []; 

  parameters.stimWarmup           = {};
  parameters.probWarmup           = {};
  parameters.outcWarmup           = {};
  parameters.corrProbRespWarmup   = {}; // same as for test/train above.

  parameters.correctWarmup        = {}; // saves the correct (judged by prob) number of trials per block
  parameters.correctTrain         = {}; // saves the correct (judged by prob) number of trials per block
  parameters.correctTest          = {}; // saves the correct (judged by prob) number of trials per block

  parameters.correctWarmupTrials  = {}; // 1 if resp prob-correct, 0 if not.
  parameters.correctTrainTrials   = {};
  parameters.correctTestTrials    = {};

  parameters.unambTestTrials      = {}; // saves number of test trials per block with a probability ≠ 0.5
  parameters.unambTrainTrials     = {}; // for parallel training only - curr train prob is always != 0.5

  parameters.coor                 = {};

  parameters.stimLocs             = {}; // index 0 corresponds to stimulus saved at position 0 etc - starting at train, then for test as well

    // task parameters
  // parameters.mapping              = randomElement([-1,1]);
  // parameters.setmean              = 0; 
  // parameters.setSTD               = shuffle([3,8]);
  // parameters.maxnum               = 9;
  // parameters.minnum               = 1;
  // parameters.boundary             = 5;

  parameters.excludedCombs        = [];

  parameters.nb_trials          =   50; // min number of train combs (here: 12)
  parameters.nb_blocks          =   8;
  parameters.trainTrialsTotal   =   parameters.nb_trials*parameters.nb_blocks;

  parameters.testNb_trials      =   50;
  parameters.testNb_blocks      =   8;
  parameters.testTrialsTotal    =   parameters.testNb_trials*parameters.testNb_blocks;

  parameters.warmup_nb_trials   =   20;
  parameters.warmup_nb_blocks   =   0; // unknown in the beginning --> will be set after warm up is finished
  parameters.warmupTrialsTotal  =   0; // also set after warmup is finished
 
  parameters.noRespCount        =   0;

  // bonus for good performance
  parameters.bonus              = {}; // saves the reward a participant earned per block
  parameters.totalBonus         = 0; // increases throughout the experiment.

  parameters.stimLocsTrain      = {};
  parameters.stimLocsTest       = {};

  // parameters.testBlock          = {}; // for each block: saves if a test block (true) or a train block (false)
  // parameters.testBlock['0']     = 0;
  parameters.testBlock          = [0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1];

  


  // SDATA ----------------
  sdata = {};
  // expt
  sdata.expt_index        = [];
  sdata.expt_trial        = [];
  sdata.expt_block        = [];
  sdata.warmup_index      = [];
  sdata.warmup_trial      = [];
  sdata.warmup_block      = [];
  // vbxi
  sdata.vbxi_category     = [];
  sdata.corrRespProb      = [];
  sdata.resp_correct_prob = [];

  // resp
  sdata.resp_timestamp    = [];
  sdata.resp_reactiontime = [];
  sdata.resp_category     = [];
  sdata.resp_correct      = [];

  sdata.betwTrialKeyPress  = {}; // counts how often participants pressed keys when answering was disabled - one entry for each block.
  for(var i=0;i<(parameters.nb_blocks+parameters.testNb_blocks)*parameters.nb_trials;i++){
    sdata.betwTrialKeyPress[i]=[]; 
    for (var j=0; j<20; j++) {
      sdata.betwTrialKeyPress[i].push(parseInt(0));
    }    
  }
  sdata.betwTrialPressPerTrial = []; 
  for (var i=0; i<(parameters.nb_blocks+parameters.testNb_blocks)*parameters.nb_trials+40; i++){
    sdata.betwTrialPressPerTrial.push(parseInt(0)); 
  }

  sdata.appear_order       = [];
  for(var i=0;i<(parameters.nb_blocks+parameters.testNb_blocks)*parameters.nb_trials;i++){
    sdata.appear_order[i] = shuffle([0,1,2,3]);
  }

  // BOARD ----------------
  board = {};
  board.stimuli = {};



  // CODING ---------------
  coding = {};
  // index
  //for warm-up
  coding.index  = 0;

  // for both
  coding.trial            = 0;
  coding.block            = 0;
  coding.warmup_block     = 0;

    // for training
  coding.trainIndex = -1; // will be incremened by 1 before start of first trial
  // coding.trainIndex = coding.index-((coding.warmup_block+1)*parameters.warmup_nb_trials);

  // for testing
  coding.testIndex = -1; // will be incremened by 1 before start of first trial
  // coding.testIndex = coding.index-parameters.trainTrialsTotal-((coding.warmup_block+1)*parameters.warmup_nb_trials);

//  coding.newblock = true;

  // other
  coding.answering = false;
  coding.timestamp = NaN;

  coding.warmup = true;
  coding.train = false;
  coding.test  = false;

  coding.instructions  = {index:0, wait:true, started:false, finished:false, response:false, instructions:[]};


  // coding.allCombs = [[0,1],[0,2],[0,3],[0,4],[0,5],[0,6],[0,7],[1,2],[1,3],[1,4],[1,5],[1,6],[1,7],[2,3],[2,4],[2,5],[2,6],[2,7],[3,4],[3,5],[3,6],[3,7],[4,5],[4,6],[4,7],[5,6],[5,7],[6,7]]; // without replacement and disregarding order.
}

function createSdata(){
  genWarmupBlock();
  getAllCombs();
  excludeCombs();

  if(parameters.cond == 0){
    genTrainCurr();
  }
  else if(parameters.cond == 1){
    genTrainParal();
  }
  genTest();
}
