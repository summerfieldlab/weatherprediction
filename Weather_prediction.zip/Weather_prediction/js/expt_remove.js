
<!-- Remove methods -->
function removeStimuli() {
	if(false){board.stimuli[0].remove();}
	else{
		for (var g= 0; g<4; g++){
			board.stimuli[g].remove();
		}
	}
}
function removeInstructions() {
  for(var i = 0;i<4;i++){	
  	board.instructions[i].remove();
  }
}
function removeFeedback() {
//  board.posfeedback.object.remove();
//  board.negfeedback.object.remove();
}
function removePaper(){
  board.paper.object.remove();
}
