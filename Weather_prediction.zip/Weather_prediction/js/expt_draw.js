
function drawStimuli(paper,stimulus) {
  var stimuli = [];
  disp('drawStimuli: FILL IN');
  return stimuli;
}


function getInstructions() {
  var instructions = [];
  parameters.whichStim = 0; //show test or training stimuli
  coding.instructions1Selcted = false;  //true as soon as stimulus demonstrating training is selected
  coding.instructions2Selected = false; //true as soon as stimulus demonstrating testing is selected
  initialisevariable()
  hideInstructions();
  hideFixation(board.fixation);
  hideClock();
  var instr_locs = {}; var four_locs = getLocs4stims();
  for(var i=0;i<4;i++){instr_locs[i] = four_locs[i];}
  loadImages(selectImageIndex(),instr_locs);// loads 4 stimuli randomly to be used during the instructions
  hideInstStim();
  // welcome!

  if(parameters.cond == 0){
    instructions[00] = ({ func: function(args) {
                          dispBG();
                          //boardRemoveTrainingText()
                          boardCreateTrainingText(args)
                           board.instructions.next.object.attr({"fill":        "#FFFFFF"});                           
                        },
                        args: [ 'Hello, thank you for your participation!',
                                "Press [DOWN] key to move forward, or [UP] to see the previous screen again."
                                ]})
    instructions[01] = ({ func: function(args) {
                          boardCreateTrainingText(args)
                          hideInstStim();
                          hideFixation(board.fixation);
                          board.instructions.next.object.attr({"fill":        "#000"}); 
                        },
                         args: ['We will now go through the instructions.',
                                'Please read them carefully.' ]})

    instructions[02] = ({ func: function(args) {
                          parameters.whichStim = 0;  // 0:train stimuli
                          boardCreateTrainingText(args)
                          showFixation(board.fixation);
                          hideInstStim();
                          // showInstStim();
                          hideInstructions();
                          coding.instructions1Selected = true;
                        },
                         args: ['At first, you will see one out of 8 objects on each trial.']})
    instructions[03] = ({ func: function(args) {
                          parameters.whichStim = 0;
                          hideInstStim();
                          // showInstStim();
                          boardCreateTrainingText(args)
                          showInstructions();  
                        },
                         args: ['Your task is to predict if the weather will be good or bad based on the objects you see.',
                                'Please use the [LEFT] and [RIGHT] arrow-key to respond.']})
    instructions[04] = ({ func: function(args) {
                          parameters.whichStim = 1; // show test stimuli
                          hideInstStim();
                          // showInstStim();
                          showInstructions();
                          boardCreateTrainingText(args)
                          coding.instructions2Selected = true;
                        },
                         args: ['Later, you will see up to 4 objects from the same set simultaneously.',
                         'Again, you are asked to predict if the weather will be good or bad based on the objects you see.']})

    instructions[05] = ({ func: function(args) {
                          hideInstStim();
                          hideInstructions();
                          boardCreateTrainingText(args)   
                          colourFixation(board.fixation,board.fixation.standard_colour); 
                        },
                         args: ['Throughout the task, please focus on the fixation cross in the middle of the screen.',
                         ]})    

    instructions[06] = ({ func: function(args) {
                          boardCreateTrainingText(args)
                          colourFixation(board.fixation,"#555"); 
                        },
                         args: ['You will be able to respond once the fixation dot turns gray. However, please take as long as you need.',
                         'After you have given a response, the fixation cross will change colour again.']})

    instructions[07] = ({ func: function(args) {
                         boardCreateTrainingText(args)
                         colourFixation(board.fixation,board.posfeedback.colour);
                         board.posfeedback.sound.play();                          
                        },
                         args: ['Green colour means your response was correct.']})
 

    instructions[08] = ({ func: function(args) {
                          boardCreateTrainingText(args)
                          showFixation(board.fixation);
                          colourFixation(board.fixation,board.negfeedback.colour);
                          board.negfeedback.sound.play();                          
                        },
                         args: ['Red colour means your response was incorrect.']})

    instructions[09] = ({ func: function(args) {
                          boardCreateTrainingText(args)
                          //if(board.fixation == undefined){                          //}
                          colourFixation(board.fixation,board.fixation.standard_colour);  
                          showFixation(board.fixation);                        
                        },
                         args: ['As you may have noticed, you will also receive auditory feedback.',
                         'Please make sure your audio is enabled so you can hear this.']})

    instructions[10] = ({ func: function(args) {
                          boardCreateTrainingText(args)
                          hideInstructions();
                          hideFixation(board.fixation);

                        },
                          args: ['Throughout the task, you might sometimes find the feedback you receive quite surprising.',
                                 ]})

    instructions[11] = ({ func: function(args) {
                          boardCreateTrainingText(args)

                        },
                          args: ['Just as in real weather forecasts, the best possible prediction may still be incorrect.',
                                 'Try learning about trends - which objects tend to indicate good or bad weather?']})

    instructions[12] = ({ func: function(args) {
                          boardCreateTrainingText(args)

                        },
                          args: ['Please just focus on which object(s) are presented for your prediction.',
                                 "Object position on the screen, their order and colour are irrelevant."]})

    instructions[13] = ({ func: function(args) {
                          boardCreateTrainingText(args)

                        },
                          args: ['The rules remain consistent over the course of the study.',
                          'Try to learn as much as possible from the beginning and you will find the later stages much easier.']})


    instructions[14] = ({ func: function(args) {
                          boardCreateTrainingText(args)

                        },
                          args: ['Please note that part of the payment you receive for this study is performance-based.',
                                 'You can earn up to £5 for good performance on top of the £5 base payment.']})

    instructions[15] = ({ func: function(args) {
                          boardCreateTrainingText(args)

                        },
                          args: ["Let's now start with a brief warm-up.",
                                "There will only be two different objects and your task is to predict the weather based on which one is presented.",
                                "",
                                "The warm-up will repeat until you choose the correct answer on 15 out of 20 trials."]})


    instructions[16] = ({ func: function(args) {
                          boardCreateTrainingText(args)

                        },
                          args: ["You can go through the instructions again if you are unsure about something.",
                          "If you believe you are encountering any technical difficulties during the study, please let us know."]})

  }

  else if(parameters.cond == 1){

    instructions[00] = ({ func: function(args) {
                          dispBG();
                          //boardRemoveTrainingText()
                          boardCreateTrainingText(args)
                           board.instructions.next.object.attr({"fill":        "#FFFFFF"});                           
                        },
                        args: [ 'Hello, thank you for your participation!',
                                "Press [DOWN] key to move forward, or [UP] to see the previous screen again."
                                ]})
    instructions[01] = ({ func: function(args) {
                          boardCreateTrainingText(args)
                          hideInstStim();
                          hideFixation(board.fixation);
                          board.instructions.next.object.attr({"fill":        "#000"}); 
                        },
                         args: ['We will now go through the instructions.',
                                'Please read them carefully.' ]})

    instructions[02] = ({ func: function(args) {
                          parameters.whichStim = 1; //1:parallel training - don't change that.
                          boardCreateTrainingText(args)
                          showFixation(board.fixation);
                          hideInstStim();
                          // showInstStim();
                          hideInstructions();
                          coding.instructions2Selected = true;
                        },
                         args: ['In this study, you will see 4 out of a set of 8 objects on each trial.']})
    instructions[03] = ({ func: function(args) {
                          hideInstStim();
                          // showInstStim();
                          boardCreateTrainingText(args)
                          showInstructions();  
                        },
                         args: ['Your task is to predict if the weather will be good or bad based on the objects you see.',
                                'Please use the [LEFT] and [RIGHT] arrow-key to respond.']})

    instructions[04] = ({ func: function(args) {
                          hideInstStim();
                          hideInstructions();
                          boardCreateTrainingText(args)   
                          colourFixation(board.fixation,board.fixation.standard_colour); 
                        },
                         args: ['Throughout the task, please focus on the fixation cross in the middle of the screen.',
                         ]})    

    instructions[05] = ({ func: function(args) {
                          boardCreateTrainingText(args)
                          colourFixation(board.fixation,"#555"); 
                        },
                         args: ['You will be able to respond once the fixation dot turns gray. However, please take as long as you need.',
                         'After you have given a response, the fixation cross will change colour again.']})

    instructions[06] = ({ func: function(args) {
                         boardCreateTrainingText(args)
                         colourFixation(board.fixation,board.posfeedback.colour);
                         board.posfeedback.sound.play();                          
                        },
                         args: ['Green colour means your response was correct.']})
 

    instructions[07] = ({ func: function(args) {
                          boardCreateTrainingText(args)
                          showFixation(board.fixation);
                          colourFixation(board.fixation,board.negfeedback.colour);
                          board.negfeedback.sound.play();                          
                        },
                         args: ['Red colour means your response was incorrect.']})

    instructions[08] = ({ func: function(args) {
                          boardCreateTrainingText(args)
                          //if(board.fixation == undefined){                          //}
                          colourFixation(board.fixation,board.fixation.standard_colour);  
                          showFixation(board.fixation);                        
                        },
                         args: ['As you may have noticed, you will also receive auditory feedback.',
                         'Please make sure your audio is enabled so you can hear this.']})

    instructions[9] = ({ func: function(args) {
                          boardCreateTrainingText(args)
                          hideInstructions();
                          hideFixation(board.fixation);

                        },
                          args: ['Throughout the task, you might sometimes find the feedback you receive quite surprising.',
                                 ]})

    instructions[10] = ({ func: function(args) {
                          boardCreateTrainingText(args)

                        },
                          args: ['Just as in real weather forecasts, the best possible prediction may still be incorrect.',
                                 'Try learning about trends - which objects tend to indicate good or bad weather?']})

    instructions[11] = ({ func: function(args) {
                          boardCreateTrainingText(args)

                        },
                          args: ['Please just focus on which object(s) are presented for your prediction.',
                                 "Object position on the screen, their order and colour are irrelevant."]})

    instructions[12] = ({ func: function(args) {
                          boardCreateTrainingText(args)

                        },
                          args: ['The rules remain consistent over the course of the study.',
                          'Try to learn as much as possible from the beginning and you will find the later stages much easier.']})


    instructions[13] = ({ func: function(args) {
                          boardCreateTrainingText(args)

                        },
                          args: ['Please note that part of the payment you receive for this study is performance-based.',
                                 'You can earn up to £5 for good performance on top of the £5 base payment.']})

    instructions[14] = ({ func: function(args) {
                          boardCreateTrainingText(args)

                        },
                          args: ["Let's now start with a brief warm-up.",
                                "You will only see 1 object out of a set of 2 on each trial."]})

    instructions[15] = ({ func: function(args) {
                          boardCreateTrainingText(args)

                        },
                          args: ["Your task is to predict the weather based on which object is presented.",
                                "The warm-up will repeat until you choose the correct answer on 15 out of 20 trials."]})

    instructions[16] = ({ func: function(args) {
                          boardCreateTrainingText(args)

                        },
                          args: ["You can go through the instructions again if you are unsure about something.",
                          "If you believe you are encountering any technical difficulties during the study, please let us know."]})
  }


    // finish training
  if(coding.warmup){
    instructions[instructions.length] = ({ func: finishInstructions,
                                           args: []})
    return instructions
  }

    instructions[17] = ({ func: function(args) {
                          dispBG();
                          boardCreateTrainingText(args)

                        },
                          args: ['Well done! You have completed the warm-up.',
                                 "Let's now continue with the main part of the study."]})

    instructions[18] = ({ func: function(args) {
                          boardCreateTrainingText(args)

                        },
                          args: ["Please remember to just focus on which object(s) are presented for your prediction.",
                                 "You will not do better by paying attention to object position, order or colour.",
                                 "There is no time pressure, so please focus on accuracy."]})

    instructions[19] = ({ func: function(args) {
                          boardCreateTrainingText(args)

                        },
                          args: ["As you may have noticed, the objects do not always indicate the same weather.",
                                 "In the main part of the study, the objects will be even more ambiguous."]})

    instructions[20] = ({ func: function(args) {
                          boardCreateTrainingText(args)

                        },
                          args: ["Try to not get too frustrated if you receive unexpected feedback for some trials.",
                                 "If you stay concentrated and focus on general trends, your efforts will pay off!"]})

    instructions[21] = ({ func: function(args) {
                          boardCreateTrainingText(args)

                        },
                          args: ["As mentioned previously, you will be able to earn a bonus of up to £5 throughout the study."]})

    instructions[22] = ({ func: function(args) {
                          boardCreateTrainingText(args)

                        },
                          args: ["After each block, we will inform you about the bonus payment that you have earned.",
                                 "You will also be able to track the progress of your bonus payment overall on the bottom of the screen."]})

    instructions[23] = ({ func: function(args) {
                          boardCreateTrainingText(args)

                        },
                          args: ["Are you ready for the main part of the study?",
                                 "Please go through the instructions again if you are unsure about something."]})




    instructions[instructions.length] = ({ func: finishInstructions,
                                         args: []})
    return instructions
}




function dispBG(){
  board.paper.bg.attr({fill:"#FFFFFF"});
}

function boardCreateTrainingText(args)  { boardCreateTrainingTextXY(board.paper.centre.concat(args)) }      // args=[  str1,str2,...]
function boardCreateTrainingTextY(args) { boardCreateTrainingTextXY([board.paper.centre[0]].concat(args)) } // args=[y,str1,str2,...]

function boardCreateTrainingTextXY(args) { dbprint()
  // args = [x,y,str1,str2,...]
  boardRemoveTrainingText();
  board.training.text = [];
  for (var i=0; i<args.length-2; i++) {
    board.training.text[i] = {};
    board.training.text[i].centre       = [args[0],args[1]-board.paper.centre[1]*0.7 - (20) * (args.length-i-2)];
    board.training.text[i].text         = args[i+2];
    board.training.text[i].object       = drawText(board.paper.object,board.training.text[i].centre,board.training.text[i].text);
    board.training.text[i].object.attr({"font-size":   18});
    board.training.text[i].object.attr({"text-anchor": "middle"});
    board.training.text[i].object.attr({"fill":        "#000"});
    $(board.training.text[i].object.node).css({"-webkit-touch-callout": "none","-webkit-user-select": "none","-khtml-user-select": "none","-moz-user-select": "none","-ms-user-select": "none","user-select": "none"}); // disable text selection
} }

function dbprint() {
  return
  var stack = StackTrace.getSync()
  var str = stack[3].functionName
  stack.splice(0,4)
  var i = 0;
  while(i<stack.length && stack[i].functionName != undefined) {
    str = stack[i].functionName + '/' + str
    i++
  }
  console.log(str)
}

function boardRemoveTrainingText() { dbprint()
  try {
    for (var i=0; i<board.training.text.length; i++) {
      board.training.text[i].object.remove();
    }
    delete board.training.text
  } catch(error) {
} }


function initialisevariable(){
  board.training  =  {};
  board.inst = {};
}

function showInstStim(){
  if(parameters.whichStim == 0){
    board.stimuli[0].attr({'opacity': 1});
  }
  else if(parameters.whichStim == 1){
    for(var i=0;i<4;i++){
      board.stimuli[i].attr({'opacity': 1});
    }
  }
}

function hideInstStim(){
  if(board.stimuli[2] != undefined){
    for(var i=0;i<4;i++){
      board.stimuli[i].attr({'opacity': 0});
    }
  }
  else if(board.stimuli[0] != undefined){
    board.stimuli[0].attr({'opacity': 0});
  }
  else{
    return;
  }
}

function removeInstStim(){
  for(var i=0;i<4;i++){
      board.stimuli[i].remove();
  }
}