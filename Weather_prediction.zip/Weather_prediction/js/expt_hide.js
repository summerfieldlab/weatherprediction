
<!-- Hide methods -->
function hideTrial() {
  hideFixation(board.fixation);
  hideStimuli();
  hideInstructions();
  hideClock();
}

function hideStimuli() {
  if(0){
      board.stimuli[0].attr({'opacity': 0});
  }
  else{
    for(var i=0;i<4;i++){
      board.stimuli[i].attr({'opacity': 0});
    }
  }
  showFixation(board.fixation)
}

function hideNumbers() {
  var nb_flankers = parameters.numFlankers;
  for (var g= 0; g<nb_flankers; g++){
    board.numbers[g].object.attr({"opacity": 0});
  }
}

function hideInstructions() {
  for(var i = 0;i<4;i++){
    board.instructions[i].attr({"opacity": 0});
  }
  if(board.instructions.progress != undefined){
    board.instructions.progress.object.attr({"opacity": 0}); 
  }
  if(board.instructions.bonus != undefined){
    board.instructions.bonus.object.attr({"opacity": 0}); 
  }
}

function hideFeedback() {
 colourFixation(board.fixation, board.fixation.standard_colour);
 // board.posfeedback.object.attr({"opacity": 0});
 // board.negfeedback.object.attr({"opacity": 0});
}

function hideWeather(){
  board.badWeather.attr({"opacity": 0});
  board.goodWeather.attr({"opacity": 0});
}

function hideBlock() {
  board.block.object.remove();
  if(board.instructions.bonus != undefined){
    board.block_bonus.object.remove();
  }
}

function hideArrows(){
  board.instructions[2].attr({"opacity": 0}); 
  board.instructions[3].attr({"opacity": 0});

}
