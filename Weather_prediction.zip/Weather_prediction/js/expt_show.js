//<!-- Show methods -->
function showTrial() {
  showFixation(board.fixation);
  showStimuli();
  showInstructions();
  // showClock();
}

function showStimuli_helper(){
  board.stimuli[sdata.appear_order[coding.testIndex+coding.trainIndex+1][coding.c]].attr({'opacity': 1});
  hideFixation(board.fixation)
  coding.c += 1
  setTimeout(hideStimuli, parameters.stim_onscreen)
  if (coding.c<4)
  {setTimeout(showStimuli_helper, parameters.isi)}
}

function showStimuli() {
  if(coding.warmup){
    if(parameters.cond == 0){ // cond 0 = curriculum learning
      board.stimuli[0].attr({'opacity': 1});
      hideFixation(board.fixation)
      setTimeout(hideStimuli, parameters.stim_onscreen)
    }
    else if(parameters.cond == 1){ // cond 1 = parallel learning
        board.stimuli[0].attr({'opacity': 1});
        board.stimuli[1].attr({'opacity': 1});
        board.stimuli[2].attr({'opacity': 1});
        board.stimuli[3].attr({'opacity': 1});
        hideFixation(board.fixation)
        setTimeout(hideStimuli, parameters.stim_onscreen)
    }
  }
  else if (parameters.cond%2==0 && (coding.testIndex==-1 && coding.trainIndex%100<50)) // no delay for singleton stims
  {
    board.stimuli[0].attr({'opacity': 1});
    board.stimuli[1].attr({'opacity': 1});
    board.stimuli[2].attr({'opacity': 1});
    board.stimuli[3].attr({'opacity': 1});
    hideFixation(board.fixation)
    setTimeout(hideStimuli, parameters.stim_onscreen)
  }
  else {
    coding.c = 0
    showStimuli_helper()
  }
}

function showInstructions() {
  for(var i=0;i<4;i++){
    board.instructions[i].attr({"opacity": 1});
  }
  if(board.instructions.progress != undefined){
    board.instructions.progress.object.attr({"opacity": 1}); 
  }
  if(board.instructions.bonus != undefined){
    board.instructions.bonus.object.attr({"opacity": 1});
  }

}

function showFeedback() {
  if(sdata.resp_correct[coding.index]){
    showFeedbackPos();
  } else {
    showFeedbackNeg();
  }
}

function showFeedbackPos() {
 colourFixation(board.fixation,board.posfeedback.colour);
 board.posfeedback.sound.play(); 
}

function showFeedbackNeg() {
  colourFixation(board.fixation,board.negfeedback.colour);
  board.negfeedback.sound.play(); 
}

function showWeather(){
  if(sdata.vbxi_category[coding.index] == 0){
    showBadWeather();
  }
  else{
    showGoodWeather();
  }
}

function showGoodWeather(){
  board.goodWeather.attr({"opacity": 1});
}

function showBadWeather(){
  board.badWeather.attr({"opacity": 1});
}

function showArrows(){
  board.instructions[2].attr({"opacity": 1}); 
  board.instructions[3].attr({"opacity": 1});
}

function showBlock(){
  board.block_bonus = {};
  board.block_bonus.centre = [board.paper.centre[0], board.paper.height-440];
  if(!coding.warmup){
    board.block_bonus.text = 'Well done! You earned ';
    if(coding.block == parameters.nb_blocks + parameters.testNb_blocks){
      var str = String(parameters.totalBonus);
      while(str.length < 3){
        str = '0' + str;
      }
      board.block_bonus.text += ' a total bonus of £ ' + str.charAt(0) + '.' + str.charAt(1) + str.charAt(2);
    }

    else if(parameters.testBlock[coding.block-1]){
      board.block_bonus.text += parameters.bonus[coding.block-1] + 'p out of 38p on this block!';
    } 
    else{
      board.block_bonus.text += parameters.bonus[coding.block-1] + 'p out of 25p on this block!';
    }
      
    board.block_bonus.object = drawText(board.paper.object,board.block_bonus.centre,board.block_bonus.text);
    board.block_bonus.object.attr({"font-size": 16});
  }

  board.block = {};
  board.block.centre = [board.paper.centre[0], board.paper.height-400];
  if(coding.warmup){
    board.block.text = "Your prediction was correct in " + getCorrectWarmup(coding.warmup_block-1) + " out of " + parameters.warmup_nb_trials + " cases. \n You need at least " + Math.ceil(parameters.warmup_nb_trials*3/4) + " correct predictions to progress to the main part of the study. \n Press the SPACE bar when you're ready to continue."; 
  }
  else if(coding.block == parameters.nb_blocks + parameters.testNb_blocks){
    board.block.text = "Press the SPACE bar to finish the experiment.";
  }
  else{
    board.block.text = "A couple of seconds break. Press the SPACE bar when you're ready to continue";
  }
  board.block.object = drawText(board.paper.object,board.block.centre,board.block.text);
  board.block.object.attr({"font-size": board.font_medsize});
}