function runExperiment(){

  board = {};

  // BIND KEYS
  jwerty.key('←',handleLeft);
  jwerty.key('→',handleRight);
  jwerty.key('space',startBlock);

  // BOARD
  // fonts
  board.font_bigsize       = 70;
  board.font_biggermedsize = 20;
  board.font_medsize       = 15;
  board.font_tinysize      = 12;
  // paper (paper)
  board.paper = {};
  board.paper.width  = window.innerWidth;
  board.paper.height = window.innerHeight;
  board.paper.centre = [0.5*window.innerWidth , 0.5*window.innerHeight];
  board.paper.rect   = [
                        0,
                        0,
                        board.paper.width,
                        board.paper.height
                       ];
  board.paper.object = drawPaper(board.paper.rect);

  board.paper.bg     = drawRect(board.paper.object,board.paper.rect); 

  // FIXATION
  board.fixation = createFixation(board.paper,1.4);
  showFixation(board.fixation);
  board.fixation.standard_colour = '#000';

  //STIMULUS --> see setExperiment
  board.numbers = {};
  board.stimuli = {};

 if(coding.index == 0){
    createSdata();
  }



  // TEXT
  // instructions (text)
  board.instructions = {};
  board.instructions.centre       = [board.paper.centre[0], board.paper.centre[1]-160];

  // position of sun and raincloud depend on k parameter in URL:
  parameters.instrCoorLeft        = [board.instructions.centre[0]-100,board.instructions.centre[1]-90];
  parameters.instrCoorRight       = [board.instructions.centre[0]+30, board.instructions.centre[1]-90];

  if(parameters.keys == 0){
      parameters.sun_position     = parameters.instrCoorRight;
      parameters.cloud_position   = parameters.instrCoorLeft;
  }
  else{
      parameters.sun_position     = parameters.instrCoorLeft;
      parameters.cloud_position   = parameters.instrCoorRight;
  }


  board.instructions[0]           = board.paper.object.image("http://185.47.61.11/sandbox/tasks/lucy/WeatherPrediction_template/Images/sun.png",parameters.sun_position[0],parameters.sun_position[1],60,60);
  board.instructions[1]           = board.paper.object.image("http://185.47.61.11/sandbox/tasks/lucy/WeatherPrediction_template/Images/raincloud.png",parameters.cloud_position[0],parameters.cloud_position[1],60,60);
  board.instructions[2]           = board.paper.object.image("http://185.47.61.11/sandbox/tasks/lucy/WeatherPrediction_template/Images/arrowLeft.png",board.instructions.centre[0]-110,board.instructions.centre[1]-30,80, 30);
  board.instructions[3]           = board.paper.object.image("http://185.47.61.11/sandbox/tasks/lucy/WeatherPrediction_template/Images/arrowRight.png",board.instructions.centre[0]+30,board.instructions.centre[1]-30,80, 30);

  board.instructions.next = {};
  board.instructions.next.centre       = [board.paper.centre[0],board.paper.height - 100];
  board.instructions.next.text         = "Press [DOWN] key to move forward\nor [UP] to see the previous screen again.";
  board.instructions.next.object       = drawText(board.paper.object,board.instructions.next.centre,board.instructions.next.text);
  board.instructions.next.object.attr({"font-size":   14});
  board.instructions.next.object.attr({"text-anchor": "middle"});
  board.instructions.next.object.attr({"fill":        "#000"});
  board.instructions.next.object.attr({"opacity":     0});
  $(board.instructions.next.object.node).css({"-webkit-touch-callout": "none","-webkit-user-select": "none","-khtml-user-select": "none","-moz-user-select": "none","-ms-user-select": "none","user-select": "none"}); // disable text selection
  /*board.instructions.text         = "<-----      ------>";
  board.instructions.object       = drawText(board.paper.object,board.instructions.centre,board.instructions.text);
  board.instructions.object.attr({"font-size": board.font_biggermedsize});
  board.instructions.object.attr({"text-anchor": "middle"});
  */

  drawProgress();
  
  // CLOCK
  drawClock([board.paper.centre[0], board.paper.centre[1]+150]);

  // COUNTDOWN
  drawCountdown("#B0B0B0",1);
  board.countdown.total = 60;

  // FEEDBACK
  // posfeedback (text)
 /* board.posfeedback = {};
  board.posfeedback.centre   = {};
  board.posfeedback.centre[0]= board.paper.centre[0];
  board.posfeedback.centre[1]= board.paper.centre[1]+70;
  board.posfeedback.text     = "Correct";
  board.posfeedback.colour   = "#2D2";
  board.posfeedback.object   = drawText(board.paper.object,board.posfeedback.centre,board.posfeedback.text);
  board.posfeedback.object.attr({"font-size": board.font_bigsize});
  board.posfeedback.object.attr({"fill": board.posfeedback.colour});
  // negfeedback (text)
  board.negfeedback = {};
  board.negfeedback.centre   = {};
  board.negfeedback.centre[0]= board.paper.centre[0];
  board.negfeedback.centre[1]= board.paper.centre[1]+70;
  board.negfeedback.text     = "Incorrect";
  board.negfeedback.colour   = "#D22";
  board.negfeedback.object   = drawText(board.paper.object,board.negfeedback.centre,board.negfeedback.text);
  board.negfeedback.object.attr({"font-size": board.font_bigsize});
  board.negfeedback.object.attr({"fill": board.negfeedback.colour});
  hideFeedback(); */

  board.posfeedback = {};
  board.posfeedback.colour   = "#2D2";
  board.negfeedback = {};
  board.negfeedback.colour   = "#D22";

  board.posfeedback.sound = new Audio("http://185.47.61.11/sandbox/tasks/lucy/WeatherPrediction_template/Sounds/Positive.wav");
  board.negfeedback.sound = new Audio("http://185.47.61.11/sandbox/tasks/lucy/WeatherPrediction_template/Sounds/Negative.wav");

/*
  //GOOD WEATHER

  board.goodWeather = {};
  board.goodWeather.centre = board.paper.centre;
  board.goodWeather = board.paper.object.image("http://185.47.61.11/sandbox/tasks/lucy/WeatherPrediction_template/Images/sun.png",board.goodWeather.centre[0]+20,board.goodWeather.centre[1]-250,50,50);

  //BAD WEATHER
  board.badWeather = {};
  board.badWeather.centre = board.paper.centre;
  board.badWeather = board.paper.object.image("http://185.47.61.11/sandbox/tasks/lucy/WeatherPrediction_template/Images/raincloud.png",board.badWeather.centre[0]-60,board.badWeather.centre[1]-250,50,50);
*/

  // START
  newTrial();
}

// allocate a position on the screen to the four stimuli in parallel training and testing
function getCoor(ag) {
  if(ag%2 == 0){parameters.coor[0] = board.paper.centre[0] - 135;} 
    else{parameters.coor[0] = board.paper.centre[0] + 45;}
  if(ag<2){parameters.coor[1] = board.paper.centre[1] + 15;}
    else{parameters.coor[1] = board.paper.centre[1] - 105;}
  return parameters.coor; 
}


// exp_stimuli OR exp_
function selectImageIndex(num){
  if(num == undefined) {num = 4;}

  parameters.images = {}; 
  
  for(var i=0;i<num;i++){
    parameters.images[i] = Math.floor(Math.random()*8+0);
    switch(parameters.images[i]){
      case parameters.images[i-1]:
      case parameters.images[i-2]:
      case parameters.images[i-3]:
      i--;
      break;
      default:
      break;
    }
  }
  return parameters.images;
}

function wait(ms)
{
    var d = new Date();
    var d2 = null;
    do { d2 = new Date(); }
    while(d2-d < ms);
}

// function loadImagesHelper(){
//   var coors = getCoor(coding.locs[coding.tmp]);
//   board.stimuli[coding.tmp] = board.paper.object.image(parameters.stimDict[coding.locs[coding.tmp]],coors[0],coors[1],90,90);
//   coding.tmp+=1
//   if (coding.tmp < Object.keys(coding.locs).length) {setTimeout(loadImagesHelper, parameters.isi)}
// }

// board.paper.centre[0]-90, board.paper.centre[1]-90.180,180

function loadImages(indices, locs){
  for(var i=0;i<Object.keys(indices).length;i++){
    var coors = getCoor(locs[i]);
    board.stimuli[i] = board.paper.object.image(parameters.stimDict[indices[i]],board.paper.centre[0]-90,board.paper.centre[1]-90,180,180);
    }
  }

function loadImageCurr(index, loc){
  if(loc == undefined){loc = Math.floor(Math.random()*4);}
  var coor = getCoor(loc);
  if(coding.warmup){
    board.stimuli[0] = board.paper.object.image(parameters.warmupStimDict[index], board.paper.centre[0]-90, board.paper.centre[1]-90, 180, 180);
  }
  else{
    //var stim = parameters.stimTrainCurr[coding.index];
    board.stimuli[0] = board.paper.object.image(parameters.stimDict[index], board.paper.centre[0]-90, board.paper.centre[1]-90, 180, 180);
  }
}

function currLoadStim(){
  if(parameters.cond == 0){
    for(var i=0;i<parameters.numStimuli;i++){
      board.stimuli[i] = board.paper.object.image(parameters.stimDict[i],board.paper.centre[0]-45,board.paper.centre[1]-45,180,180);
    }
    hideStimuli();
  }
}

function getLocs4stims(){
  var locs = []
  locs.push(Math.floor(Math.random()*4));
  for(var i = 1; i<4;i++){
    var new_loc = Math.floor(Math.random()*4);
    if(locs.includes(new_loc)){
      i --;
    }
    else{
      locs.push(new_loc);
    }
  }
  return locs;
}


// function genTrainCurr(numTrials){
//   if (numTrials == undefined){numTrials = parameters.nb_trials*parameters.nb_blocks;} //numTrials should be dividable by 8!
//   if(numTrials % 8 != 0){disp('change number of trials!')};
//   var numPresentStim = numTrials/8;
//   selectStimOrderCurr();
//   for(var j=0;j<parameters.numStimuli;j++){
//     for(var i=0;i<numPresentStim;i++){
//       parameters.stimTrainCurr[(numPresentStim*j+i)] = parameters.stimOrder[j];
//     }
//   }
//   if(parameters.training_method == 1){
//     shuffleCurr(parameters.stimTrainCurr);
//   }

//   for(var k=0;k<numTrials;k++){
//     parameters.stimLocsTrain[k] = Math.floor(Math.random()*4);
//   }

//   computeProbTrain();
//   computeOutcTrain();
// }
function selectStimOrder_return(num){
  if(num == undefined) {num = 8;} // 8 different stimuli used in the task.

  out = {};

  for(var i=0;i<num;i++){
    out[i] = Math.floor(Math.random()*8+0);
    switch(out[i]){
      case out[i-1]:
      case out[i-2]:
      case out[i-3]:
      case out[i-4]:
      case out[i-5]:
      case out[i-6]:
      case out[i-7]: 
      i--;
      break;
      default:
      break;
    }
  }
  return out; 
}

function findStimWLargestP(array){
  var largest=0;
  for (var i=0; i<array.length; i++){
    if (array[i]>largest){
      largest=array[i]
    }
  }
  var index = array.indexOf(largest);
  return index 
}

function genTrainCurr(numTrials){
  var order_blocks = selectStimOrder_return();
  var currentStim = [0, 0]; 
  var probDict = []; 
  var selectedPool = []; 

  if (numTrials == undefined){numTrials = parameters.nb_trials*parameters.nb_blocks;} //numTrials should be divisible by 8!
 
  for (var i=0; i<numTrials; i++){ //setting up an object of stim combination at each trial 
    parameters.stimTrainCurr[i]={}; 
    parameters.stimLocsTrain[i]={}
  }

  for (var i=0; i<Object.keys(parameters.probDict).length; i++){ //convert all stim to int in selectpool for manipulations later on
    probDict[i]=Math.abs(parseFloat(parameters.probDict[i])-.5); 
  }

  for (var blockIndex = 0; blockIndex < parameters.nb_blocks; blockIndex++){
    if (blockIndex%2==0){
      for (var i =0;i<2; i++){
        var ind = findStimWLargestP(probDict); 
        currentStim[i]=ind; 
        selectedPool.push(ind); 
        probDict[ind]=0; 
      }

      for (var i=0; i<50; i++){
        var temp=getLocs4stims(); 
        parameters.stimTrainCurr[blockIndex*50+i][0]=currentStim[Math.round(Math.random())]; 
        parameters.stimLocsTrain[blockIndex*50+i][0]=temp[Math.floor(Math.random()*4)]; 
      }

      currentStim[0]=0; 
      currentStim[0]=0; 
    }
    else{
      for (var i=0; i<50; i++){
        var comb = genComb(selectedPool); 
        if(combInArray(parameters.allValidCombs, comb)){
            var temp=getLocs4stims(); 
            for (var j=0; j<4; j++){
              parameters.stimTrainCurr[blockIndex*50+i][j]=comb[j]; 
              parameters.stimLocsTrain[blockIndex*50+i][j]=temp[j]; 
            } 
        }
        else{
          i--; 
        }
      }
    }
  }

  computeProbTrain();
  computeOutcTrain();

}

function genWarmupBlock(){
  parameters.stimWarmup[coding.warmup_block] = {};
  parameters.probWarmup[coding.warmup_block] = {};
  parameters.outcWarmup[coding.warmup_block] = {};
  for(var i = 0;i<parameters.warmup_nb_trials;i++){
    var rand = Math.floor(Math.random()*2);
      parameters.stimWarmup[coding.warmup_block][i] = rand;
  }
  warmupProbOutc();
}

function warmupProbOutc(){
  for(var i=0;i<parameters.warmup_nb_trials;i++){
      parameters.probWarmup[coding.warmup_block][i] = parameters.warmupProbDict[parameters.stimWarmup[coding.warmup_block][i]];

      var index = parameters.warmup_nb_trials * coding.warmup_block;
      if(parameters.probWarmup[coding.warmup_block][i] > 0.5){
        parameters.corrProbRespWarmup[index + i]  = 1;
      }
      else{
        parameters.corrProbRespWarmup[index + i]  = 0;
      }
  }
  for(var i=0;i<parameters.warmup_nb_trials;i++){
      var rand = Math.random();
      if(rand<parameters.probWarmup[coding.warmup_block][i]){
        parameters.outcWarmup[coding.warmup_block][i] = 1;
      }
      else{
        parameters.outcWarmup[coding.warmup_block][i] = 0;
      }
  }
}

/*function shuffleCurr(curriculum) {
    for (var i = parameters.trainTrialsTotal - 1; i > 0; i--) {
        var j = Math.floor(Math.random() * (i + 1));
        var temp = curriculum[i];
        curriculum[i] = curriculum[j];
        curriculum[j] = temp;
    }
    parameters.stimTrainCurr = curriculum;
}*/

function selectStimOrderCurr(num){
  if(num == undefined) {num = 8;} // 8 different stimuli used in the task.

  parameters.stimOrder = {};

  for(var i=0;i<num;i++){
    parameters.stimOrder[i] = Math.floor(Math.random()*8+0);
    switch(parameters.stimOrder[i]){
      case parameters.stimOrder[i-1]:
      case parameters.stimOrder[i-2]:
      case parameters.stimOrder[i-3]:
      case parameters.stimOrder[i-4]:
      case parameters.stimOrder[i-5]:
      case parameters.stimOrder[i-6]:
      case parameters.stimOrder[i-7]: 
      i--;
      break;
      default:
      break;
    }
  }
}

// generate trials for parallel training condition
function genTrainParal(numTrials){
  if (numTrials == undefined){numTrials = parameters.nb_trials*parameters.nb_blocks;}
  parameters.stimTrainParal = {};

  var nb_train_combs = Object.keys(parameters.allValidCombs).length;
  var nb_pres_per_comb = Math.floor(numTrials / nb_train_combs);


  var stimTrain_dict = {};
  for(var i=0; i<=nb_train_combs;i++){ // create array with (here) 34 x each stimulus pair
    for(var j=0;j<nb_pres_per_comb;j++){
      if(i<nb_train_combs){
        var ind = i*nb_pres_per_comb + j;
        stimTrain_dict[ind] = [];
        for(var stim=0;stim<4;stim++){
          stimTrain_dict[ind].push(parameters.allValidCombs[i][stim]);
        }
      }
      else{
        while(Object.keys(stimTrain_dict).length < numTrials){
          var ind = Object.keys(stimTrain_dict).length;
          var rand = Math.floor(Math.random() * nb_train_combs);
          stimTrain_dict[ind] = [];
          for(var stim=0;stim<4;stim++){
            stimTrain_dict[ind].push(parameters.allValidCombs[rand][stim]);
          }
        }
      }
    }

  }
  array_trial_nb = [];
  for(var count=0;count<numTrials;count++){
    array_trial_nb.push(count);
  }
  for (var i = array_trial_nb.length - 1; i > 0; i--) {
    var j = Math.floor(Math.random() * (i + 1));
    var temp = array_trial_nb[i];
    array_trial_nb[i] = array_trial_nb[j];
    array_trial_nb[j] = temp;
  }


  for(var i=0;i<numTrials;i++){
    var trial = array_trial_nb[i];

    parameters.stimTrainParal[i] = {};
    parameters.stimLocsTrain[i] = {};
    var train_locs = getLocs4stims();
    for(var stim=0;stim<4;stim++){
      parameters.stimTrainParal[i][stim] = stimTrain_dict[trial][stim];
      parameters.stimLocsTrain[i][stim]  = train_locs[stim]; // INDEX links stimulus and location...
    }
    // select location and save that directly as well
    
  }

  computeProbTrain();
  computeOutcTrain();
}

function excludeCombs(){
  var comb;
  var logLR;
  for(var i=0; i<parameters.allCombs.length; i++){
    comb = parameters.allCombs[i]
    logLR = computeProbParal(comb);
    if(logLR > -.1 && logLR < 0.1){
      parameters.excludedCombs.push(comb);
    }
  }

  var j = 0;
  for(var i = 0; i<parameters.allCombs.length; i++){
    if(combInArray(parameters.excludedCombs,parameters.allCombs[i])){
      continue;
    }
    else{
      parameters.allValidCombs[j]    = {}
      for(var ind=0;ind<4;ind++){
        parameters.allValidCombs[j][ind] = parameters.allCombs[i][ind];
      }
      j++;
    }
  } 
}

function count(stim,array){
  var count = 0;
  for(var i = 0; i < array.length; ++i){
    if(array[i] == stim)
        count++;
  }
  return count;
}

function shuffleArray(array){
  for (var i = array.length - 1; i > 0; i--) {
    var j = Math.floor(Math.random() * (i + 1));
    var temp = array[i];
    array[i] = array[j];
    array[j] = temp;
  }
}

function removeElement(array, element){
  for(var i = 0; i<array.length; i++){
    if(array[i] == element){
      var index = i;
      break;
    }
  }
  array.splice(index,1);
  if(index == undefined){disp('error');}
  return array;
}

function combInArray(array,comb){ // assumes that all combs are sorted.
  for(var i = 0; i<array.length;i++){
    if(((array[i][0] == comb[0]) && (array[i][1] == comb[1])) && ((array[i][2] == comb[2]) && array[i][3] == comb[3])){
      return true;
    }
  }
  return false;
}

/*function drawCombs(){
  // disp('drawcombs...')
  var valid_combs = [];
  for(var i = 0; i<Object.keys(parameters.testCombs).length; i++){
    valid_combs.push(parameters.testCombs[i]);
  }

  var stim_pool = [0,1,2,3,4,5,6,7,0,1,2,3,4,5,6,7,0,1,2,3,4,5,6,7,0,1,2,3,4,5,6,7,0,1,2,3,4,5,6,7,0,1,2,3,4,5,6,7,0,1,2,3,4,5,6,7,0,1,2,3,4,5,6,7,0,1,2,3,4,5,6,7,0,1,2,3,4,5,6,7,0,1,2,3,4,5,6,7,0,1,2,3,4,5,6,7,0,1,2,3,4,5,6,7,0,1,2,3,4,5,6,7,0,1,2,3,4,5,6,7,0,1,2,3,4,5,6,7];
  var combs1    = []; // train combs
  var combs2    = []; // combs showing during test only
  var skip      = false;
  for(var stim=0;stim<8;stim++){
    for(var stim_count = count(stim,stim_pool);stim_count>0; stim_count--){
      if(skip == true){
        break;
      }
      shuffleArray(stim_pool);
      removeElement(stim_pool,stim);
      var c = 0;
      // disp('combs1: ' + combs1);
      var current_stims = sortStimTrial([stim, stim_pool[0], stim_pool[1], stim_pool[2]]);
      // disp(combInArray(combs1,current_stims));
      while(((combInArray(valid_combs,current_stims) == false) || combInArray(combs1,current_stims)) && skip==false){
        shuffleArray(stim_pool);
        var current_stims = sortStimTrial([stim, stim_pool[0], stim_pool[1], stim_pool[2]]);
        c++;
        if(c>2000){
          drawCombs();
          skip = true;
        }
      }

      if(skip == false){
        var draw1 = stim_pool.shift();
        var draw2 = stim_pool.shift();
        var draw3 = stim_pool.shift();
        var this_comb_one = sortStimTrial([stim,draw1,draw2,draw3]);
        combs1.push(this_comb_one);
        // disp('found one!!');
        // disp(stim_pool);
      }
    }
  }
  if(skip == false){
    for(var ind = 0; ind<valid_combs.length; ind++){
      if(combInArray(combs1,[valid_combs[ind][0], valid_combs[ind][1], valid_combs[ind][2], valid_combs[ind][3]])){
        continue;
      }
      else{
        combs2.push([valid_combs[ind][0], valid_combs[ind][1], valid_combs[ind][2], valid_combs[ind][3]]);
      }
    }
    // disp('combs1, combs2: ');
    // disp(combs1);
    // disp(combs2);

    for(var i = 0; i<combs1.length; i++){
      parameters.trainCombs[i] = [];
      for(var stim=0;stim<4;stim++){
        parameters.trainCombs[i][stim] = combs1[i][stim]
      }

      parameters.testOnlyCombs.push(combs2[i]);
    }
  }
  // disp('trainCombsb: ' + JSON.stringify(parameters.trainCombs));
  // disp(parameters.testCombs);
  // disp(parameters.testOnlyCombs);

}*/

function make_string(input){
  str0 = JSON.stringify(input[0]);
  str1 = JSON.stringify(input[1]);
  var output = (str0 + ', ' + str1); 
  return output;
}


function computeProbTrain(){
  if(parameters.cond == 0){
    for(var i=0;i<parameters.nb_blocks*parameters.nb_trials;i++){
      tmp=0
      for(var k=0;k<Object.keys(parameters.stimTrainCurr[(i)]).length;k++){ 
        tmp = tmp+Math.log10(computeLR(parameters.probDict[parameters.stimTrainCurr[i][k]]));
      }
      parameters.logLRtrainCurr[i] = tmp;

      parameters.probTrainCurr[i] = 10**tmp/(1+10**tmp); //parameters.probDict[parameters.stimTrainCurr[i]];

      if(parameters.logLRtrainCurr[i] > 0){
        parameters.corrProbRespTrain[i]  = 1;
      }
      else{
        parameters.corrProbRespTrain[i]  = 0;
      }
    }
  }
  else if (parameters.cond == 1){
    var prob   = {};
    var lR     = {};
    var loglR  = {};
    var check3 = {};
    var check4 = {};
    for(var i=0;i<parameters.nb_trials*parameters.nb_blocks;i++){
      for(var j=0;j<4;j++){
       prob[j] = parameters.probDict[parameters.stimTrainParal[i][j]];
       lR[j] = computeLR(prob[j]);
       loglR[j] = Math.log10(lR[j]);
      }
      parameters.logLRtrainParal[i] = loglR[0]+loglR[1]+loglR[2]+loglR[3];    
      if(parameters.logLRtrainParal[i] > 0){
        parameters.corrProbRespTrain[i]  = 1;
      }
      else if(parameters.logLRtrainParal[i] < 0){
        parameters.corrProbRespTrain[i]  = 0;
      }
      else{
        parameters.corrProbRespTrain[i]  = -1;
      }

      check3[i] = Math.pow(10, parameters.logLRtrainParal[i]);
      parameters.probTrainParal[i] = (check3[i]/(1+check3[i]));
    }
  }
}

function computeProbParal(stim){
  var prob = {};
  var lR   = {};
  var loglR= {};
  for(var j=0;j<4;j++){
    prob[j] = parameters.probDict[stim[j]];
    lR[j] = computeLR(prob[j]);
    loglR[j] = Math.log10(lR[j]);
  }
  var result = loglR[0]+loglR[1]+loglR[2]+loglR[3];
  return result;
}

function computeOutcTrain(){
  var rand;
  if(parameters.cond == 0){
    for(var i=0;i<parameters.nb_blocks*parameters.nb_trials;i++){
      rand = Math.random();
      if(rand<parameters.probTrainCurr[i]){
        parameters.outcTrainCurr[i] = 1;
      }
      else{
        parameters.outcTrainCurr[i] = 0;
      }
    }
  }
  else if(parameters.cond == 1){  // compute outcome for parallel training condition.
    for(var i=0;i<parameters.nb_blocks*parameters.nb_trials;i++){
      rand = Math.log10(computeLR(Math.random()));
      if(rand<parameters.logLRtrainParal[i]){
        parameters.outcTrainParal[i] = 1;
      }
      else{
        parameters.outcTrainParal[i] = 0;
      }
    }
  }
}

function genTest(numTrials){
  if (numTrials == undefined){numTrials = parameters.testNb_trials*parameters.testNb_blocks;}
  //var count_diff_trials = 0;

  //var nb_test_combs = Object.keys(parameters.testCombs).length;
  // disp('NB TEST COMBOS: ' + nb_test_combs);
 // var nb_pres_per_comb = Math.floor(numTrials / nb_test_combs); // minimum number that each combination should be presented.

  // stimTest_dict = {};
  // var novel = 0;
  // var famil = 0;

  // for(var i=0; i<=nb_test_combs;i++){ // create array with (here) 34 x each stimulus pair
  //   for(var j=0;j<nb_pres_per_comb;j++){
  //     if(i<nb_test_combs){
  //       var ind = i*nb_pres_per_comb + j;

  //       if(parameters.cond == 1){
  //         if(combInArray(parameters.testOnlyCombs,parameters.testCombs[i])){novel++;}
  //         else{famil++;}
  //       }

  //       stimTest_dict[ind] = [];
  //       for(var stim=0;stim<4;stim++){
  //         stimTest_dict[ind].push(parameters.testCombs[i][stim]);  
  //       }
  //     }
  //     else{
  //       while(Object.keys(stimTest_dict).length < numTrials){
  //         var ind = Object.keys(stimTest_dict).length;
  //         var rand = Math.floor(Math.random() * nb_test_combs);

  //         // CHECK EQUAL NUMBER OF NOVEL AND FAMIL TEST TRIALS.
  //         if(parameters.cond == 1){  
  //           if(combInArray(parameters.testOnlyCombs,parameters.testCombs[rand])){
  //             if(novel>=200){continue;}
  //             else{novel++;}
  //           }
  //           else{
  //             if(famil>=200){continue;}
  //             else{famil++;}
  //           }
  //         }  

  //         stimTest_dict[ind] = [];
  //         for(var stim=0;stim<4;stim++){
  //           stimTest_dict[ind].push(parameters.testCombs[rand][stim]);  
  //         }
  //       }
  //     }
  //   }

  
  // BOTH NOVEL AND FAMIL COMBS SHOULD BE EXACTLY 200 IN PARALLEL TESTING.
  // if(novel>0 && famil>0){
  //   disp('novel: ' + novel);
  //   disp('famil: ' + famil);
  // }
  // initialise array with trial numbers

  for(var i=0;i<numTrials;i++){
    parameters.stimTest[i] = {};
    parameters.stimLocsTest[i] = {};
    var test_locs = getLocs4stims();
    for(var stim=0;stim<4;stim++){
      parameters.stimTest[i][stim] = parameters.allValidCombs[Math.floor(Math.random()*parameters.allValidCombs.length)][stim];
      parameters.stimLocsTest[i][stim]  = test_locs[stim];
    }
  }

    //check if stim is unique to testing:
    // if(parameters.cond==1){
    //   var newtest = false;
    //   if(combInArray(parameters.testOnlyCombs, parameters.stimTest[i])){
    //     newtest = true;
    //   }
    //   if(newtest){parameters.novelStimComb[i] = 1;} else{parameters.novelStimComb[i] = 0;}
    // }
  // disp('stimTest');
  // disp(parameters.stimTest);
  // disp('stimTrain');
  // disp(parameters.stimTrain);
  // disp('test only combs');
  // disp(parameters.testOnlyCombs);

  // disp('novel stim comb');
  // disp(parameters.novelStimComb);
  // var sum = 0;
  // for(num of Object.values(parameters.novelStimComb)){sum += num;}

  computeProbTest();
  computeOutcTest();
}

// function sortStimTrial(stim){

//   var presented        = {};
//   var current_stim;

//   for(var j=0;j<4;j++){ // 4 different stimuli
//     presented[j] = parseInt(stim[String(j)]);
//     current_stim = presented[j];
//     //disp(current_stim);
//     var z = 1;
//     // disp('entering while loop');
//     while(current_stim<presented[j-z] && (j-z) >= 0){
//     //switch positions
//       // disp('in while loop')
//       presented[j+1-z]   = presented[j-z];
//       presented[j-z]     = current_stim;
//       z++;
//     }
//   }
//   return presented;
// }

function genComb(array){//generate one single combination and order them
  var comb = {}; 
  for (var i=0; i<4; i++){
    var rand = Math.floor(Math.random()*array.length); 
    comb[i]=array[rand]; 
  }
  
  for (var i=0; i<4; i++){ //sort each comb
    var temp = comb[i]; 
    for(var j=1; j<4-i; j++)
    while(comb[i]>comb[i+j]){
      comb[i]=comb[i+j]; 
      comb[i+j]=temp; 
    }
  }

  for (var i=0; i<4; i++){ //convert all stimuli into int
    comb[i]=parseInt(comb[i]); 
  }
  return comb; 
}

function getAllCombs(){//get all possible combinations, 330 in total  
  var comb=genComb(Object.keys(parameters.stimDict));
  parameters.allCombs.push(comb); //push one comb to allCombs to allow subsequent comparison 
  while(parameters.allCombs.length<=330){ 
    var temp = genComb(Object.keys(parameters.stimDict)); 
    if(combInArray(parameters.allCombs, temp)){
      if(parameters.allCombs.length==330){break} 
      continue; 
    }
    else{
      parameters.allCombs.push(temp); 
    }
  }
}

function computeProbTest(){
  var prob = {};
  var lR = {};
  var logLR = {};
  var check;
  var check2;
  var check3 = {};
  var check4 = {};
  for(var i=0;i<parameters.testNb_blocks*parameters.testNb_trials;i++){
    for(var j=0;j<4;j++){
      prob[j] = parameters.probDict[parameters.stimTest[i][j]];
      lR[j] = computeLR(prob[j]);
      logLR[j] = Math.log10(lR[j]);
      check = Math.pow(10, logLR[j]);
      check2 = (check/(1+check));
      //disp(check2); 
    }
    
    parameters.logLRtest[i] = logLR[0]+logLR[1]+logLR[2]+logLR[3];

    if(parameters.logLRtest[i] > 0){
      parameters.corrProbRespTest[i]  = 1;
    }
    else if(parameters.logLRtest[i] < 0){
      parameters.corrProbRespTest[i]  = 0;
    }
    else{
      parameters.corrProbRespTest[i]  = -1;
    }

    check3[i] = Math.pow(10, parameters.logLRtest[i]);
    parameters.probTest[i] = (check3[i]/(1+check3[i]));
  }
 // disp(check4);
}

function computeLR(prob){
  var lR = (prob/(1-prob));
  return lR;
}

function computeOutcTest(){
  var rand;
  var index;
  var y = 0;
  for(var i=0;i<parameters.testNb_blocks*parameters.testNb_trials;i++){
    rand  = Math.log10(computeLR(Math.random()));
    //rand = Math.random();
    if(rand<parameters.logLRtest[i]){
      parameters.outcTest[i] = 1; // the index is accesssed by coding.index which counts up from the first training trial
     y++;
    }
    else{
      parameters.outcTest[i] = 0; // the index is accesssed by coding.index which counts up from the first training trial
    }
  }
}

function drawProgress(){
  if(!coding.warmup){
    if(coding.block>0){ // coding.block stays 0 during warm-up.
      board.instructions.progress.object.remove();
      board.instructions.bonus.object.remove();
    }

    board.instructions.progress              = {};
    board.instructions.progress.centre       = [board.paper.centre[0],board.paper.height - 190];
    board.instructions.progress.text         = "Block " + (coding.block+1) + " out of " + String(parameters.nb_blocks + parameters.testNb_blocks);
    board.instructions.progress.object       = drawText(board.paper.object,board.instructions.progress.centre,board.instructions.progress.text);
    board.instructions.progress.object.attr({"font-size":   12});
    board.instructions.progress.object.attr({"text-anchor": "middle"});
    board.instructions.progress.object.attr({"fill":        "#000"});
    board.instructions.progress.object.attr({"opacity":     0});


    board.instructions.bonus              = {};
    board.instructions.bonus.centre       = [board.paper.centre[0],board.paper.height - 215];


    if(coding.block == 0){
      board.instructions.bonus.text       = 'No bonus earned so far.';  
    }

    else if(coding.block > 0){
      var str = String(parameters.totalBonus);
      while(str.length < 3){
        str = '0' + str;
      }

      board.instructions.bonus.text       = 'Bonus earned: £' + str.charAt(0) + '.' + str.charAt(1) + str.charAt(2);
    }

    board.instructions.bonus.object       = drawText(board.paper.object,board.instructions.bonus.centre,board.instructions.bonus.text);
    board.instructions.bonus.object.attr({"font-size":   14});
    board.instructions.bonus.object.attr({"text-anchor": "middle"});
    board.instructions.bonus.object.attr({"fill":        "#000"});
    board.instructions.bonus.object.attr({"opacity":     0});

  }
}

function finishWarmup(){
  parameters.warmup_nb_blocks  = coding.warmup_block+1; // coding.warmup_block starts at 0
  parameters.warmupTrialsTotal = parameters.warmup_nb_blocks * parameters.warmup_nb_trials;

  coding.warmup = false;
  coding.train  = true;
  coding.trial  = 0;
  coding.instructions  = {index:17, wait:true, started:false, finished:false, response:false, instructions:[]};

  removeFeedback();
  removeStimuli();
  removeFixation(board.fixation);
  //removeFixation(board.fixation);

  board.paper = {};
  board.paper.width  = window.innerWidth;
  board.paper.height = window.innerHeight;
  board.paper.centre = [0.5*window.innerWidth , 0.5*window.innerHeight];
  board.paper.rect   = [
                        0,
                        0,
                        board.paper.width,
                        board.paper.height
                       ];
  board.paper.object = drawPaper(board.paper.rect);

  board.paper.bg     = drawRect(board.paper.object,board.paper.rect);
  board.fixation     = createFixation(board.paper,1.4);
  showFixation(board.fixation);
  board.fixation.standard_colour = '#000';

  board.instructions.next = {};
  board.instructions.next.centre       = [board.paper.centre[0],board.paper.height - 100];
  board.instructions.next.text         = "Press [DOWN] key to move forward\nor [UP] to see the previous screen again.";
  board.instructions.next.object       = drawText(board.paper.object,board.instructions.next.centre,board.instructions.next.text);
  board.instructions.next.object.attr({"font-size":   14});
  board.instructions.next.object.attr({"text-anchor": "middle"});
  board.instructions.next.object.attr({"fill":        "#000"});
  board.instructions.next.object.attr({"opacity":     0});
  $(board.instructions.next.object.node).css({"-webkit-touch-callout": "none","-webkit-user-select": "none","-khtml-user-select": "none","-moz-user-select": "none","-ms-user-select": "none","user-select": "none"}); // disable text selection

  launchInstructions();
  // launch second part of instructions --> when finished: launch actual experiment!
  // perhaps just call this launch instructions2 and copy all the code but display different elements?
}

function getCorrectWarmup(block){
  if(block == undefined){block = coding.warmup_block};
  var count_correct = 0;
  var index_start = block * parameters.warmup_nb_trials;
  parameters.correctWarmup[block] = {};
  for(var i=0;i<parameters.warmup_nb_trials;i++){
    if(sdata.resp_correct_prob[index_start + i] == 1){
      parameters.correctWarmup[block][i] = 1;
      count_correct++;
    }
    else{
      parameters.correctWarmup[block][i] = 0;
    }
  }
  return count_correct;
}

function getPercCorrPerBlock(block){
  var train_trials_so_far = coding.trainIndex + 1; // starting at 0
  disp("TRAIN TRIALS SO FAR");
  disp(train_trials_so_far);
  var test_trials_so_far = coding.testIndex;
  if(test_trials_so_far > 0){
    test_trials_so_far++;
  }
  disp("TEST TRIALS SO FAR");
  disp(test_trials_so_far);

  // var test_block = parameters.testBlock[block];
  var test_block = 0
  if (block>7) {test_block = 1}

  var count_train_blocks=-1; var count_test_blocks=-1; // first block should be 0, not 1.
  for(var i=0;i<=block;i++){
    if(parameters.testBlock[i]==0){
      count_train_blocks++;
    }
    else{
      count_test_blocks++;
    }
  }

  var total_trials_so_far = parameters.warmupTrialsTotal + train_trials_so_far + test_trials_so_far; // assuming this function is not used for warmup (see getCorrectWarmup() above)
  if(test_block == 0){
    disp('COUNT TRAIN BLOCKS: ' + count_train_blocks)
    var trials = parameters.nb_trials;
    index_start = total_trials_so_far - trials; // above statement sets index to the total numbers of trials up to that point.
    parameters.correctTrain[count_train_blocks] = 0;
    parameters.correctTrainTrials[count_train_blocks] = {};
    var ambiguous_train_trials = 0;
    for(var i = 0; i<parameters.nb_trials; i++){
      if(sdata.resp_correct_prob[index_start+i] == 1){
        parameters.correctTrainTrials[count_train_blocks][i] = 1;
        parameters.correctTrain[count_train_blocks]++;
      }
      else if(sdata.resp_correct_prob[index_start+i] == 0){
        parameters.correctTrainTrials[count_train_blocks][i] = 0;
      }
      else if(sdata.resp_correct_prob[index_start+i] == -1){
        parameters.correctTrainTrials[count_train_blocks][i] = -1;
        ambiguous_train_trials++;
      }
    }
    // disp('correct trials this block: ' + parameters.correctTrain[block]);
    // disp('more precisely: ' + JSON.stringify(parameters.correctTrainTrials[block]));

    parameters.unambTrainTrials[count_train_blocks] = parameters.nb_trials-ambiguous_train_trials;
    var perc_corr = parameters.correctTrain[count_train_blocks]*100/parameters.unambTrainTrials[count_train_blocks];
  }
  else if(test_block == 1){
    disp('COUNT TEST BLOCKS: ' + count_test_blocks)
    parameters.correctTest[count_test_blocks] = 0;
    parameters.correctTestTrials[count_test_blocks] = {};
    var ambiguous_test_trials = 0;
    var trials = parameters.testNb_trials;
    index_start = total_trials_so_far - trials;
    for(var i = 0; i<trials; i++){
      //disp('testtrialssofar: ' + test_trials_so_far);

      if(sdata.resp_correct_prob[index_start+i] == 1){
        parameters.correctTestTrials[count_test_blocks][i] = 1;
        parameters.correctTest[count_test_blocks]++;
      }
      else if(sdata.resp_correct_prob[index_start+i] == 0){
        parameters.correctTestTrials[count_test_blocks][i] = 0;
      }
      else if(sdata.resp_correct_prob[index_start+i] == -1){
        parameters.correctTestTrials[count_test_blocks][i] = -1;
        ambiguous_test_trials++;
      }
    }
    // disp('block_test = ' + block_test);
    // disp('Correct: ' + parameters.correctTest[block_test]);
    // disp('More precisely: ' + JSON.stringify(parameters.correctTestTrials[block_test]));
    parameters.unambTestTrials[count_test_blocks] = parameters.testNb_trials-ambiguous_test_trials;
    //disp('unambiguous test trials on this block: ' + parameters.unambTestTrials[block_test]);
    var perc_corr = parameters.correctTest[count_test_blocks]*100/parameters.unambTestTrials[count_test_blocks];
  }

  // disp('% correct: ' + perc_corr);
  return perc_corr

}


function fixation(){
  board.fixation = createFixation(board.paper,1.4);
  showFixation(board.fixation);
  board.fixation.standard_colour = '#000';
}

function updateIndices(){
  if(coding.train){
    coding.trainIndex++;
    disp('trainIndex: ' + coding.trainIndex);
  }
  if(coding.test){
    coding.testIndex++;
    disp('test index ' + coding.testIndex);
  }
  // coding.trainIndex = coding.index-((coding.warmup_block+1)*parameters.warmup_nb_trials);
  // coding.testIndex = coding.index-parameters.trainTrialsTotal-((coding.warmup_block+1)*parameters.warmup_nb_trials);
}

function calculateBonus(){
  var max_bonus;
  // for training:
  if(coding.train){
    max_bonus = 25;
  }
  else if(coding.test){
    max_bonus = 38;
  }
  else{
    return;
  }

  parameters.bonus[coding.block] = Math.round(getPercCorrPerBlock(coding.block) * max_bonus / 100);

  parameters.totalBonus += parameters.bonus[coding.block];
  // for testing:

}


function getTrainORTest(){
  if(coding.block == parameters.nb_blocks + parameters.testNb_blocks){
    disp('EXP FINISHED');
    return;
  }

  if(parameters.interl_test == 1){
    if(coding.block % 2 == 0){
      coding.train = true;
      coding.test  = false;
      parameters.testBlock[coding.block] = 0; // meaning it's a training block 
      disp("TRAIN BLOCK ABOUT TO START");
    }
    else{
      coding.train = false;
      coding.test  = true;
      parameters.testBlock[coding.block] = 1; // meaning it's a test block
      disp('TEST BLOCK ABOUT TO START');
    }
  disp('test block?');
  disp(parameters.testBlock); 
  }
  else{
    if(coding.block<parameters.nb_blocks){
      coding.train = true;
      coding.test  = false;
      disp('train block - cond 0');
    }
    else{
      coding.train = false;
      coding.test  = true;
      disp('test block - cond 0');
    }
  }
}