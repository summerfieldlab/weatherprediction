html_humanform = "html/turker_form.html";

var participant_age    = '';
var participant_gender = '';
var participant_turker = '';
function getTurkerform(){
  participant_age    = document.getElementById("ageSelect").value;
  participant_gender = document.getElementById("genderSelect").value;
  participant_turker = document.getElementById("turkerSelect").value;
}